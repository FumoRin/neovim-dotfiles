return {
  {
    "mason-org/mason.nvim",
    config = function()
      require("mason").setup({
        registries = {
          "github:mason-org/mason-registry"
        },
        PATH = "append",
      })
    end
  },
  {
    "mason-org/mason-lspconfig.nvim",
    dependencies = { "mason-org/mason.nvim" }, -- Critical dependency
    version = "1.29.0",
    config = function()
      require("mason-lspconfig").setup({
        ensure_installed = { "lua_ls", "tsserver" },
        automatic_installation = true, -- Recommended setting
        automatic_enable = true,
      })
    end,
  },
  {
    "neovim/nvim-lspconfig",
    config = function()
      local capabilities = require('cmp_nvim_lsp').default_capabilities()
      local lspconfig = require("lspconfig")
      local home = vim.fn.expand("~")
      lspconfig.lua_ls.setup({
        capabilities = capabilities
      })
      capabilities = capabilities,
      lspconfig.yamlls.setup({
        settings = {
          yaml = {
            completion = true,
            hover = true,
            validate = true,
            format = { enable = true },
            schemaStore = { enable = false },
            schemas = {
              ["https://raw.githubusercontent.com/yannh/kubernetes-json-schema/master/v1.27.0-standalone-strict/all.json"] = {
                home .. "/k8s/**"
              },
            },
          },
        },
      })
      vim.keymap.set('n', 'H', vim.lsp.buf.hover, {})
      vim.keymap.set('n', '<C-j>', vim.lsp.buf.definition, {})
      vim.keymap.set({ 'n', 'v' }, '<leader>ca', vim.lsp.buf.code_action, {})
    end
  }
}
