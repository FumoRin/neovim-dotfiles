return {
  "nvim-neo-tree/neo-tree.nvim",
  branch = "v3.x",
  dependencies = {
    "nvim-lua/plenary.nvim",
    "nvim-tree/nvim-web-devicons",
    "muniftanjim/nui.nvim",
  },
  config = function()
    vim.keymap.set('n', '<C-n>', ':Neotree toggle<CR>')

    require("neo-tree").setup({
      default_component_configs = {
        icon = {
          folder_closed = "",
          folder_open = "",
          folder_empty = "",
        },
        git_status = {
          symbols = {
            added     = "", -- nf-fa-plus
            modified  = "", -- nf-oct-pencil
            deleted   = "", -- nf-oct-trashcan
            renamed   = "", -- nf-oct-file_symlink_file
            untracked = "", -- nf-oct-question
            ignored   = "", -- nf-oct-eye_closed
            unstaged  = "", -- nf-oct-dot
            staged    = "", -- nf-fa-check
            conflict  = "", -- nf-dev-git_merge
          },
        }
      }
    })
  end
}
